### 0.1.7 - 21.02.2017
* First Azure app services version under http://fable-suave.azurewebsites.net